from django.shortcuts import render
from django.contrib.auth.decorators import login_required
# Create your views here.
from django.http import HttpResponse
from .models import Post


def index(request):
    # return HttpResponse("Hello, world. You're at the polls index.")
    years=[]
    genres=[]
    directors=[]
    for post in Post.objects.all():
        if post.year not in years: 
            years.append(post.year)
        if post.genre not in genres:
            genres.append(post.genre)    
        if post.director not in directors:
             directors.append(post.director)
    print(years)




    context = {
        'posts': Post.objects.all(),
        'years':years,
        'genres':genres,
        'directors':directors,
    }
    return render(request, 'blogapp/index.html', context)

def film(request, postid):
    years=[]
    genres=[]
    directors=[]
    for post in Post.objects.all():
        if post.year not in years: 
            years.append(post.year)
        if post.genre not in genres:
            genres.append(post.genre)    
        if post.director not in directors:
             directors.append(post.director)
    context = {
        # pk это номер фильма.поста
        'film': Post.objects.get(pk=postid),
        'years':years,
        'genres':genres,
        'directors':directors,
        

    }
    return render(request, 'blogapp/film.html', context)
def genres(request, genre):
    
    context = {
        'posts':Post.objects.filter(genre=genre)
    }
    return render(request, 'blogapp/index.html', context)
# def blockbuster(request):
#     context = {
#         'posts':Post.objects.filter(genre='Блокбастер')
#     }
#     return render(request, 'blogapp/index.html', context)
# def cartoon(request):
#     context = {
#         'posts':Post.objects.filter(genre='Мультфильм')
#     }
#     return render(request, 'blogapp/index.html', context)

# def drama(request):
#     context = {
#         'posts':Post.objects.filter(genre='Драма')
#     }
#     return render(request, 'blogapp/index.html', context)