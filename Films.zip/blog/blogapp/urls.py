from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('', views.index, name='index'),
    path('film/<str:postid>',views.film, name='film' ),
    # path('blockbuster/', views.blockbuster, name='blockbuster'),
    path('Жанры/<str:genre>', views.genres, name='genres')
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)