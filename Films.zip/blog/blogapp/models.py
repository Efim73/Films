from django.db import models

# Create your models here.
class Post(models.Model):
    genres=(
        ('Драма', "Драма"),
        ('Блокбастер', "Блокбастер"),
        ('Комедия', "Комедия"),
        ('Мультфильм', "Мультфильм"),

    )
    heading = models.CharField(max_length=200)
    post_text = models.CharField(max_length=200)
    director = models.CharField(max_length=200)
    year = models.CharField(max_length=200)
    image = models.ImageField(upload_to='images/')
    image2 = models.ImageField(upload_to='images/', default='1.jpg')
    image3 = models.ImageField(upload_to='images/', default='1.jpg')
    genre = models.CharField(max_length=200,choices=genres)

